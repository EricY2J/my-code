#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from threading import Thread
from inputimeout import inputimeout, TimeoutOccurred
import time

player_id = "player_1"  # 玩家编号，每个玩家脚本不同

# 全局变量来存储主题词和已选词
current_topic_word = ""
used_words = []
start1 = False
start2 = False


def topic_word_callback(msg):
    global current_topic_word, start1
    current_topic_word = msg.data
    rospy.loginfo(f"收到主题词: {current_topic_word}")
    start1 = True

def used_words_callback(msg):
    global used_words, start2
    start2 = True
    if start1 and start2:
        used_words = msg.data.split(', ')  # 假设已选词是以逗号分隔的字符串
        if used_words == ['win']:
            print("You win!")
            rospy.signal_shutdown("Game Over") 
        else:
            rospy.loginfo(f"收到已选词更新: {used_words}")


def ask_for_answer():
    start_time = time.time()  # 记录函数开始的时间
    while True:  # 开始循环以允许重试
        try:
            # 计算剩余时间，确保整体不超过10秒
            remaining_time = 10 - (time.time() - start_time)
            if remaining_time <= 0:
                raise TimeoutOccurred  # 如果时间用尽，则引发超时异常
            answer = inputimeout(prompt='请输入你的答案（10秒内）: ', timeout=remaining_time)
            if answer in used_words[0].split(','):
                rospy.loginfo("这个词已经被使用过了，请重新输入。")
                continue  # 如果词已被使用，则继续循环，让用户重新输入
            return answer  # 如果输入的词没有被使用过，则返回这个词并结束函数
        except TimeoutOccurred:
            rospy.loginfo("时间到，未能输入答案。")
            return None  # 如果用户在限定时间内未能输入，则返回“认输”并结束函数

def answer_logic():
    answer = ask_for_answer()
    if answer:
        pub.publish(answer)
    else:
        # 可以发送一个特定的消息，比如"认输"，或者处理超时的逻辑
        pub.publish("认输")
        rospy.signal_shutdown("You are lost")

if __name__ == '__main__':
    rospy.init_node(player_id, anonymous=True)
    rospy.Subscriber("topic_word", String, topic_word_callback)
    rospy.Subscriber("used_words", String, used_words_callback)
    pub = rospy.Publisher('answer_' + player_id, String, queue_size=10)

    # 使用定时器或者在接收到主题词后调用answer_logic
    rate = rospy.Rate(0.1)  # 每10秒尝试一次

    while not rospy.is_shutdown():
        if start1 and start2:
            answer_logic()
            rate.sleep()
            start2 = False
