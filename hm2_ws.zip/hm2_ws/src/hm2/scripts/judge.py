#!/usr/bin/env python
import rospy
from std_msgs.msg import String

answers = []  # 存储所有玩家的回答
players = ["player_1", "player_2"]  # 所有玩家的列表，初始化时包含所有参与玩家


def answer_callback(msg, player_id):
    if "认输" in msg.data:
        players.remove(player_id)
        rospy.loginfo(f"{player_id} 已认输")
        if len(players) == 1:
            rospy.loginfo(f"游戏结束，赢家是 {players[0]}")
            pub.publish('win')
            rospy.signal_shutdown("Game Over")
        pass
    else:
        answers.append(msg.data)
        rospy.loginfo(f"收到 {player_id} 的回答: {msg.data}")


if __name__ == '__main__':
    rospy.init_node('judge', anonymous=True)
    pub = rospy.Publisher('used_words', String, queue_size=10)

    for player_id in players:
        rospy.Subscriber('answer_' + player_id, String, answer_callback, player_id)

    rate = rospy.Rate(0.1)
    update_msg = String()
    while not rospy.is_shutdown():
        update_msg.data = ','.join(answers)
        pub.publish(update_msg)
        rate.sleep()
    
    rospy.spin()
