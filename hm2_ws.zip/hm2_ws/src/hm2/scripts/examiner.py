#!/usr/bin/env python
import rospy
from std_msgs.msg import String
import time

def examiner():
    rospy.init_node('examiner', anonymous=True)
    pub = rospy.Publisher('topic_word', String, queue_size=10)
    rate = rospy.Rate(1.0/300)  # 每5分钟发布一次
    topics = ["果园", "菜园", "动物园"]

    rospy.sleep(3)

    while not rospy.is_shutdown():
        for topic in topics:
            rospy.loginfo(f"新的主题词是: {topic}")
            pub.publish(topic)
            rate.sleep()

if __name__ == '__main__':
    try:
        examiner()
    except rospy.ROSInterruptException:
        pass
